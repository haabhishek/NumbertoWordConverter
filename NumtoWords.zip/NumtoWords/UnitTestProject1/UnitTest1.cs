﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NumbtoWords;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            //Arrange
            string n1 = "23";

            //Act
            string result=NumtoWords.Convertntow(n1);

            //Assert
            Assert.AreEqual(result, "Twenty Three");
            
        }

        [TestMethod]
        public void TestMethod2()
        {
            //Arrange
            string n2 = "15495";

            //Act
            string result = NumtoWords.Convertntow(n2);

            //Assert
            Assert.AreEqual(result, "Fifteen Thousand Four Hundred and Ninety Five");
        }

        [TestMethod]
        public void TestMethod3()
        {
            //Arrange
            string n3 = "56945781";

            //Act
            string expected = NumtoWords.Convertntow(n3);
            string actual = "Fifty Six Million Nine Hundred and Forty Five Thousand Seven Hundred and Eighty One";

            //Assert
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void TestMethod4()
        {
            //Arrange
            string n4 = "999999999";

            //Act
            string expected = NumtoWords.Convertntow(n4);
            string actual = "Nine Hundred and Ninety Nine Million Nine Hundred and Ninety Nine Thousand Nine Hundred and Ninety Nine";
            
            //Assert
            Assert.AreEqual(expected, actual);
        }
    }
}
